# This entrypoint file to be used in development. Start by reading README.md
import demographic_data_analyzer
from unittest import main
import pandas as pd 
# Test your function by calling it here

demographic_data_analyzer.calculate_demographic_data()
df = pd.read_csv("adult.data.csv")

print(sum(df.loc[(df['education'] == "Bachelors") | (df['education'] == "Masters") | (df['education'] == "Doctorate")]['salary'] == '>50K') / len(df.loc[(df['education'] == "Bachelors") | (df['education'] == "Masters") | (df['education'] == "Doctorate")].index) * 100)
# Run unit tests automatically
main(module='test_module', exit=False)