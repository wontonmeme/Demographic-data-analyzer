# Demographic Data Analyzer

This folder will contain two things, 
my calculations file and a zip folder of the freecodecamp
files and such that I had to fill in order to finish the 
project. I may start posting more advanced
projects which will include regression, data 
visualization, and machine learning like testing and
training MSPE after getting the hang of numpy, pandas, 
and tensorflow. 
