# Demographic Data Analyzer

This folder will contain two things, 
my calculations file and a markdown file detailing 
what questions I had to answer and the calculations 
I did to get it. I may start posting more advanced
projects which will include regression, data 
visualization, and machine learning like testing and
training MSPE after getting the hang of numpy, pandas, 
and tensorflow. 
